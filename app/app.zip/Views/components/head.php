<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Ftt-Online</title>
<link href="https://fonts.googleapis.com/css?family=Nunito:400,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Prata&display=swap" rel="stylesheet">
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous"> -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<link rel="stylesheet" href="/public/css/style.css">
<link rel="apple-touch-icon" sizes="180x180" href="/public/img/favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/public/img/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicons/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicons/android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicons/android-chrome-512x512.png">
<link rel="icon" type="image/png" href="/public/img/FTT_Online_Logo@640.png" sizes="32x32">
<link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicons/favicon.ico">
<meta name="msapplication-TileColor" content="#151515">
<meta name="theme-color" content="#151515">
